<?php
$host = "localhost";
$username = "root"; // adjust as per typical xampp/wamp default
$password = "";

try {
    // 1. Connect without DB
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2. Create database
    $sql = "CREATE DATABASE IF NOT EXISTS student_db";
    $pdo->exec($sql);

    // 3. Connect to the specific database
    $pdo->exec("USE student_db");

    // 4. Create table students
    $sql = "CREATE TABLE IF NOT EXISTS students (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL
    )";
    $pdo->exec($sql);
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
